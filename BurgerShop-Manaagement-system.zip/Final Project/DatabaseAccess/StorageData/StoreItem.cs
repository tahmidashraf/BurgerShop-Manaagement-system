﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseAccess.StorageData
{
    public class StoreItem
    {
        public string ItemId
        {
            get; set;
        }
        public string ItemCategory
        {
            get;set;
        }
        public string ItemName
        {
            get; set;
        }
        public string ItemPrice
        {
            get; set;
        }
    }
}
