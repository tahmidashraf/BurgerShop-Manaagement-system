﻿
namespace newdesign
{
    partial class UpdatePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblUPassword = new System.Windows.Forms.Label();
            this.txtUPassword = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtCUPassword = new Guna.UI2.WinForms.Guna2TextBox();
            this.lblCUPassword = new System.Windows.Forms.Label();
            this.btnUpPass = new Guna.UI2.WinForms.Guna2Button();
            this.btnupSigninU = new Guna.UI2.WinForms.Guna2Button();
            this.txtUpUName = new Guna.UI2.WinForms.Guna2TextBox();
            this.lblUName = new System.Windows.Forms.Label();
            this.btnUpPasAd = new Guna.UI2.WinForms.Guna2Button();
            this.SuspendLayout();
            // 
            // lblUPassword
            // 
            this.lblUPassword.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUPassword.Location = new System.Drawing.Point(203, 96);
            this.lblUPassword.Name = "lblUPassword";
            this.lblUPassword.Size = new System.Drawing.Size(229, 23);
            this.lblUPassword.TabIndex = 0;
            this.lblUPassword.Text = "New Password";
            // 
            // txtUPassword
            // 
            this.txtUPassword.BorderRadius = 10;
            this.txtUPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtUPassword.DefaultText = "";
            this.txtUPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtUPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtUPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtUPassword.DisabledState.Parent = this.txtUPassword;
            this.txtUPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtUPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtUPassword.FocusedState.Parent = this.txtUPassword;
            this.txtUPassword.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUPassword.ForeColor = System.Drawing.Color.Black;
            this.txtUPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtUPassword.HoverState.Parent = this.txtUPassword;
            this.txtUPassword.Location = new System.Drawing.Point(207, 130);
            this.txtUPassword.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtUPassword.Name = "txtUPassword";
            this.txtUPassword.PasswordChar = '\0';
            this.txtUPassword.PlaceholderText = "";
            this.txtUPassword.SelectedText = "";
            this.txtUPassword.ShadowDecoration.Parent = this.txtUPassword;
            this.txtUPassword.Size = new System.Drawing.Size(298, 40);
            this.txtUPassword.TabIndex = 4;
            // 
            // txtCUPassword
            // 
            this.txtCUPassword.BorderRadius = 10;
            this.txtCUPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCUPassword.DefaultText = "";
            this.txtCUPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtCUPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtCUPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtCUPassword.DisabledState.Parent = this.txtCUPassword;
            this.txtCUPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtCUPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtCUPassword.FocusedState.Parent = this.txtCUPassword;
            this.txtCUPassword.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCUPassword.ForeColor = System.Drawing.Color.Black;
            this.txtCUPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtCUPassword.HoverState.Parent = this.txtCUPassword;
            this.txtCUPassword.Location = new System.Drawing.Point(207, 225);
            this.txtCUPassword.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtCUPassword.Name = "txtCUPassword";
            this.txtCUPassword.PasswordChar = '\0';
            this.txtCUPassword.PlaceholderText = "";
            this.txtCUPassword.SelectedText = "";
            this.txtCUPassword.ShadowDecoration.Parent = this.txtCUPassword;
            this.txtCUPassword.Size = new System.Drawing.Size(298, 40);
            this.txtCUPassword.TabIndex = 6;
            this.txtCUPassword.TextChanged += new System.EventHandler(this.txtCUPassword_TextChanged);
            // 
            // lblCUPassword
            // 
            this.lblCUPassword.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCUPassword.Location = new System.Drawing.Point(203, 191);
            this.lblCUPassword.Name = "lblCUPassword";
            this.lblCUPassword.Size = new System.Drawing.Size(229, 23);
            this.lblCUPassword.TabIndex = 5;
            this.lblCUPassword.Text = "Confirm Password";
            // 
            // btnUpPass
            // 
            this.btnUpPass.BorderRadius = 10;
            this.btnUpPass.CheckedState.Parent = this.btnUpPass;
            this.btnUpPass.CustomImages.Parent = this.btnUpPass;
            this.btnUpPass.FillColor = System.Drawing.Color.Black;
            this.btnUpPass.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpPass.ForeColor = System.Drawing.Color.White;
            this.btnUpPass.HoverState.Parent = this.btnUpPass;
            this.btnUpPass.Location = new System.Drawing.Point(242, 299);
            this.btnUpPass.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpPass.Name = "btnUpPass";
            this.btnUpPass.ShadowDecoration.Parent = this.btnUpPass;
            this.btnUpPass.Size = new System.Drawing.Size(227, 36);
            this.btnUpPass.TabIndex = 8;
            this.btnUpPass.Text = "Update Password";
            this.btnUpPass.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnupSigninU
            // 
            this.btnupSigninU.BorderRadius = 10;
            this.btnupSigninU.CheckedState.Parent = this.btnupSigninU;
            this.btnupSigninU.CustomImages.Parent = this.btnupSigninU;
            this.btnupSigninU.FillColor = System.Drawing.Color.Black;
            this.btnupSigninU.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold);
            this.btnupSigninU.ForeColor = System.Drawing.Color.White;
            this.btnupSigninU.HoverState.Parent = this.btnupSigninU;
            this.btnupSigninU.Location = new System.Drawing.Point(523, 13);
            this.btnupSigninU.Margin = new System.Windows.Forms.Padding(4);
            this.btnupSigninU.Name = "btnupSigninU";
            this.btnupSigninU.ShadowDecoration.Parent = this.btnupSigninU;
            this.btnupSigninU.Size = new System.Drawing.Size(167, 32);
            this.btnupSigninU.TabIndex = 12;
            this.btnupSigninU.Text = "Sign In";
            this.btnupSigninU.Click += new System.EventHandler(this.btnupSigninU_Click);
            // 
            // txtUpUName
            // 
            this.txtUpUName.BorderColor = System.Drawing.SystemColors.Control;
            this.txtUpUName.BorderRadius = 10;
            this.txtUpUName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtUpUName.DefaultText = "";
            this.txtUpUName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtUpUName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtUpUName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtUpUName.DisabledState.Parent = this.txtUpUName;
            this.txtUpUName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtUpUName.FillColor = System.Drawing.SystemColors.Control;
            this.txtUpUName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtUpUName.FocusedState.Parent = this.txtUpUName;
            this.txtUpUName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpUName.ForeColor = System.Drawing.Color.Black;
            this.txtUpUName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtUpUName.HoverState.Parent = this.txtUpUName;
            this.txtUpUName.Location = new System.Drawing.Point(171, 14);
            this.txtUpUName.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtUpUName.Name = "txtUpUName";
            this.txtUpUName.PasswordChar = '\0';
            this.txtUpUName.PlaceholderText = "";
            this.txtUpUName.SelectedText = "";
            this.txtUpUName.ShadowDecoration.Parent = this.txtUpUName;
            this.txtUpUName.Size = new System.Drawing.Size(298, 40);
            this.txtUpUName.TabIndex = 14;
            this.txtUpUName.Visible = false;
            // 
            // lblUName
            // 
            this.lblUName.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUName.Location = new System.Drawing.Point(179, 14);
            this.lblUName.Name = "lblUName";
            this.lblUName.Size = new System.Drawing.Size(229, 23);
            this.lblUName.TabIndex = 13;
            this.lblUName.Text = "User Name";
            this.lblUName.Visible = false;
            // 
            // btnUpPasAd
            // 
            this.btnUpPasAd.BorderRadius = 10;
            this.btnUpPasAd.CheckedState.Parent = this.btnUpPasAd;
            this.btnUpPasAd.CustomImages.Parent = this.btnUpPasAd;
            this.btnUpPasAd.FillColor = System.Drawing.Color.Black;
            this.btnUpPasAd.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpPasAd.ForeColor = System.Drawing.Color.White;
            this.btnUpPasAd.HoverState.Parent = this.btnUpPasAd;
            this.btnUpPasAd.Location = new System.Drawing.Point(242, 299);
            this.btnUpPasAd.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpPasAd.Name = "btnUpPasAd";
            this.btnUpPasAd.ShadowDecoration.Parent = this.btnUpPasAd;
            this.btnUpPasAd.Size = new System.Drawing.Size(227, 36);
            this.btnUpPasAd.TabIndex = 15;
            this.btnUpPasAd.Text = "Update Password";
            this.btnUpPasAd.Click += new System.EventHandler(this.btnUpPasAd_Click);
            // 
            // UpdatePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 390);
            this.Controls.Add(this.btnUpPasAd);
            this.Controls.Add(this.txtUpUName);
            this.Controls.Add(this.lblUName);
            this.Controls.Add(this.btnupSigninU);
            this.Controls.Add(this.btnUpPass);
            this.Controls.Add(this.txtCUPassword);
            this.Controls.Add(this.lblCUPassword);
            this.Controls.Add(this.txtUPassword);
            this.Controls.Add(this.lblUPassword);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UpdatePassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button btnupSigninU;
        private System.Windows.Forms.Label lblUName;
        public Guna.UI2.WinForms.Guna2TextBox txtUpUName;
        public Guna.UI2.WinForms.Guna2Button btnUpPass;
        public Guna.UI2.WinForms.Guna2Button btnUpPasAd;
        public System.Windows.Forms.Label lblUPassword;
        public Guna.UI2.WinForms.Guna2TextBox txtUPassword;
        public Guna.UI2.WinForms.Guna2TextBox txtCUPassword;
        public System.Windows.Forms.Label lblCUPassword;
    }
}