﻿
namespace newdesign
{
    partial class SignIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignIn));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblReadytoLogin = new System.Windows.Forms.Label();
            this.lblusername = new System.Windows.Forms.Label();
            this.txtinUserName = new Guna.UI2.WinForms.Guna2TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.btninSigninEmp = new Guna.UI2.WinForms.Guna2Button();
            this.btninSignUp = new Guna.UI2.WinForms.Guna2Button();
            this.txtinPassword = new Guna.UI2.WinForms.Guna2TextBox();
            this.btnPassShow = new System.Windows.Forms.Button();
            this.btnPassHide = new System.Windows.Forms.Button();
            this.lblHaveAcc = new System.Windows.Forms.Label();
            this.fgPassword = new System.Windows.Forms.LinkLabel();
            this.lblAdmin = new System.Windows.Forms.Label();
            this.lnlblAdmin = new Guna.UI.WinForms.GunaLinkLabel();
            this.lnlblEmp = new Guna.UI.WinForms.GunaLinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.btninSigninAdm = new Guna.UI2.WinForms.Guna2Button();
            this.lnlblFrAd = new System.Windows.Forms.LinkLabel();
            this.btnCross = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(573, 539);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblReadytoLogin
            // 
            this.lblReadytoLogin.AutoSize = true;
            this.lblReadytoLogin.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReadytoLogin.Location = new System.Drawing.Point(717, 124);
            this.lblReadytoLogin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblReadytoLogin.Name = "lblReadytoLogin";
            this.lblReadytoLogin.Size = new System.Drawing.Size(185, 28);
            this.lblReadytoLogin.TabIndex = 1;
            this.lblReadytoLogin.Text = "Ready to Login";
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.Location = new System.Drawing.Point(620, 182);
            this.lblusername.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(99, 19);
            this.lblusername.TabIndex = 2;
            this.lblusername.Text = "User Name";
            // 
            // txtinUserName
            // 
            this.txtinUserName.BorderRadius = 10;
            this.txtinUserName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtinUserName.DefaultText = "";
            this.txtinUserName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtinUserName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtinUserName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtinUserName.DisabledState.Parent = this.txtinUserName;
            this.txtinUserName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtinUserName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtinUserName.FocusedState.Parent = this.txtinUserName;
            this.txtinUserName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinUserName.ForeColor = System.Drawing.Color.Black;
            this.txtinUserName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtinUserName.HoverState.Parent = this.txtinUserName;
            this.txtinUserName.Location = new System.Drawing.Point(624, 207);
            this.txtinUserName.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtinUserName.Name = "txtinUserName";
            this.txtinUserName.PasswordChar = '\0';
            this.txtinUserName.PlaceholderText = "";
            this.txtinUserName.SelectedText = "";
            this.txtinUserName.ShadowDecoration.Parent = this.txtinUserName;
            this.txtinUserName.Size = new System.Drawing.Size(349, 46);
            this.txtinUserName.TabIndex = 3;
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.Location = new System.Drawing.Point(620, 262);
            this.lblPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(87, 19);
            this.lblPassword.TabIndex = 4;
            this.lblPassword.Text = "Password";
            // 
            // btninSigninEmp
            // 
            this.btninSigninEmp.BorderRadius = 10;
            this.btninSigninEmp.CheckedState.Parent = this.btninSigninEmp;
            this.btninSigninEmp.CustomImages.Parent = this.btninSigninEmp;
            this.btninSigninEmp.FillColor = System.Drawing.Color.Black;
            this.btninSigninEmp.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninSigninEmp.ForeColor = System.Drawing.Color.White;
            this.btninSigninEmp.HoverState.Parent = this.btninSigninEmp;
            this.btninSigninEmp.Location = new System.Drawing.Point(689, 387);
            this.btninSigninEmp.Margin = new System.Windows.Forms.Padding(4);
            this.btninSigninEmp.Name = "btninSigninEmp";
            this.btninSigninEmp.ShadowDecoration.Parent = this.btninSigninEmp;
            this.btninSigninEmp.Size = new System.Drawing.Size(227, 42);
            this.btninSigninEmp.TabIndex = 7;
            this.btninSigninEmp.Text = "Sign In";
            this.btninSigninEmp.Click += new System.EventHandler(this.btninSigninEmp_Click);
            // 
            // btninSignUp
            // 
            this.btninSignUp.BorderRadius = 10;
            this.btninSignUp.CheckedState.Parent = this.btninSignUp;
            this.btninSignUp.CustomImages.Parent = this.btninSignUp;
            this.btninSignUp.FillColor = System.Drawing.Color.Black;
            this.btninSignUp.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninSignUp.ForeColor = System.Drawing.Color.White;
            this.btninSignUp.HoverState.Parent = this.btninSignUp;
            this.btninSignUp.Location = new System.Drawing.Point(835, 35);
            this.btninSignUp.Margin = new System.Windows.Forms.Padding(4);
            this.btninSignUp.Name = "btninSignUp";
            this.btninSignUp.ShadowDecoration.Parent = this.btninSignUp;
            this.btninSignUp.Size = new System.Drawing.Size(152, 33);
            this.btninSignUp.TabIndex = 8;
            this.btninSignUp.Text = "Sign Up";
            this.btninSignUp.Click += new System.EventHandler(this.btninSignUp_Click);
            // 
            // txtinPassword
            // 
            this.txtinPassword.BorderRadius = 10;
            this.txtinPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtinPassword.DefaultText = "";
            this.txtinPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtinPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtinPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtinPassword.DisabledState.Parent = this.txtinPassword;
            this.txtinPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtinPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtinPassword.FocusedState.Parent = this.txtinPassword;
            this.txtinPassword.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinPassword.ForeColor = System.Drawing.Color.Black;
            this.txtinPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtinPassword.HoverState.Parent = this.txtinPassword;
            this.txtinPassword.Location = new System.Drawing.Point(624, 287);
            this.txtinPassword.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtinPassword.Name = "txtinPassword";
            this.txtinPassword.PasswordChar = '*';
            this.txtinPassword.PlaceholderText = "";
            this.txtinPassword.SelectedText = "";
            this.txtinPassword.ShadowDecoration.Parent = this.txtinPassword;
            this.txtinPassword.Size = new System.Drawing.Size(349, 46);
            this.txtinPassword.TabIndex = 9;
            // 
            // btnPassShow
            // 
            this.btnPassShow.Image = ((System.Drawing.Image)(resources.GetObject("btnPassShow.Image")));
            this.btnPassShow.Location = new System.Drawing.Point(981, 287);
            this.btnPassShow.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPassShow.Name = "btnPassShow";
            this.btnPassShow.Size = new System.Drawing.Size(43, 46);
            this.btnPassShow.TabIndex = 10;
            this.btnPassShow.UseVisualStyleBackColor = true;
            this.btnPassShow.Click += new System.EventHandler(this.btnPassShow_Click);
            // 
            // btnPassHide
            // 
            this.btnPassHide.Image = ((System.Drawing.Image)(resources.GetObject("btnPassHide.Image")));
            this.btnPassHide.Location = new System.Drawing.Point(981, 287);
            this.btnPassHide.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPassHide.Name = "btnPassHide";
            this.btnPassHide.Size = new System.Drawing.Size(43, 46);
            this.btnPassHide.TabIndex = 12;
            this.btnPassHide.UseVisualStyleBackColor = true;
            this.btnPassHide.Visible = false;
            this.btnPassHide.Click += new System.EventHandler(this.btnPassHide_Click);
            // 
            // lblHaveAcc
            // 
            this.lblHaveAcc.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHaveAcc.Location = new System.Drawing.Point(630, 35);
            this.lblHaveAcc.Name = "lblHaveAcc";
            this.lblHaveAcc.Size = new System.Drawing.Size(197, 32);
            this.lblHaveAcc.TabIndex = 13;
            this.lblHaveAcc.Text = "Don\'t have an account?";
            this.lblHaveAcc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // fgPassword
            // 
            this.fgPassword.AutoSize = true;
            this.fgPassword.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fgPassword.LinkColor = System.Drawing.Color.Black;
            this.fgPassword.Location = new System.Drawing.Point(823, 338);
            this.fgPassword.Name = "fgPassword";
            this.fgPassword.Size = new System.Drawing.Size(150, 24);
            this.fgPassword.TabIndex = 14;
            this.fgPassword.TabStop = true;
            this.fgPassword.Text = "Forgot Password";
            this.fgPassword.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.fgPassword_LinkClicked);
            // 
            // lblAdmin
            // 
            this.lblAdmin.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdmin.Location = new System.Drawing.Point(685, 472);
            this.lblAdmin.Name = "lblAdmin";
            this.lblAdmin.Size = new System.Drawing.Size(142, 32);
            this.lblAdmin.TabIndex = 15;
            this.lblAdmin.Text = "Sign in as an";
            this.lblAdmin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lnlblAdmin
            // 
            this.lnlblAdmin.AutoSize = true;
            this.lnlblAdmin.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnlblAdmin.Location = new System.Drawing.Point(810, 475);
            this.lnlblAdmin.Name = "lnlblAdmin";
            this.lnlblAdmin.Size = new System.Drawing.Size(74, 23);
            this.lnlblAdmin.TabIndex = 16;
            this.lnlblAdmin.TabStop = true;
            this.lnlblAdmin.Text = "Admin";
            this.lnlblAdmin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnlblAdmin.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnlblAdmin_LinkClicked);
            // 
            // lnlblEmp
            // 
            this.lnlblEmp.AutoSize = true;
            this.lnlblEmp.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnlblEmp.Location = new System.Drawing.Point(810, 475);
            this.lnlblEmp.Name = "lnlblEmp";
            this.lnlblEmp.Size = new System.Drawing.Size(108, 23);
            this.lnlblEmp.TabIndex = 18;
            this.lnlblEmp.TabStop = true;
            this.lnlblEmp.Text = "Employee";
            this.lnlblEmp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnlblEmp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnlblEmp_LinkClicked);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(685, 466);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 38);
            this.label1.TabIndex = 17;
            this.label1.Text = "Sign in as an";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btninSigninAdm
            // 
            this.btninSigninAdm.BorderRadius = 10;
            this.btninSigninAdm.CheckedState.Parent = this.btninSigninAdm;
            this.btninSigninAdm.CustomImages.Parent = this.btninSigninAdm;
            this.btninSigninAdm.FillColor = System.Drawing.Color.Black;
            this.btninSigninAdm.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninSigninAdm.ForeColor = System.Drawing.Color.White;
            this.btninSigninAdm.HoverState.Parent = this.btninSigninAdm;
            this.btninSigninAdm.Location = new System.Drawing.Point(689, 387);
            this.btninSigninAdm.Margin = new System.Windows.Forms.Padding(4);
            this.btninSigninAdm.Name = "btninSigninAdm";
            this.btninSigninAdm.ShadowDecoration.Parent = this.btninSigninAdm;
            this.btninSigninAdm.Size = new System.Drawing.Size(227, 42);
            this.btninSigninAdm.TabIndex = 19;
            this.btninSigninAdm.Text = "Sign In";
            this.btninSigninAdm.Click += new System.EventHandler(this.btninSigninAdm_Click);
            // 
            // lnlblFrAd
            // 
            this.lnlblFrAd.AutoSize = true;
            this.lnlblFrAd.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnlblFrAd.LinkColor = System.Drawing.Color.Black;
            this.lnlblFrAd.Location = new System.Drawing.Point(823, 338);
            this.lnlblFrAd.Name = "lnlblFrAd";
            this.lnlblFrAd.Size = new System.Drawing.Size(150, 24);
            this.lnlblFrAd.TabIndex = 20;
            this.lnlblFrAd.TabStop = true;
            this.lnlblFrAd.Text = "Forgot Password";
            this.lnlblFrAd.Visible = false;
            this.lnlblFrAd.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnlblFrAd_LinkClicked);
            // 
            // btnCross
            // 
            this.btnCross.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCross.Location = new System.Drawing.Point(1012, 12);
            this.btnCross.Name = "btnCross";
            this.btnCross.Size = new System.Drawing.Size(29, 28);
            this.btnCross.TabIndex = 21;
            this.btnCross.Text = "✖";
            this.btnCross.UseVisualStyleBackColor = true;
            this.btnCross.Click += new System.EventHandler(this.btnCross_Click);
            // 
            // SignIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1053, 539);
            this.Controls.Add(this.btnCross);
            this.Controls.Add(this.lnlblFrAd);
            this.Controls.Add(this.btninSigninAdm);
            this.Controls.Add(this.lnlblEmp);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lnlblAdmin);
            this.Controls.Add(this.lblAdmin);
            this.Controls.Add(this.fgPassword);
            this.Controls.Add(this.lblHaveAcc);
            this.Controls.Add(this.btnPassHide);
            this.Controls.Add(this.btnPassShow);
            this.Controls.Add(this.txtinPassword);
            this.Controls.Add(this.btninSignUp);
            this.Controls.Add(this.btninSigninEmp);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.txtinUserName);
            this.Controls.Add(this.lblusername);
            this.Controls.Add(this.lblReadytoLogin);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SignIn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblReadytoLogin;
        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.Label lblPassword;
        private Guna.UI2.WinForms.Guna2Button btninSigninEmp;
        private Guna.UI2.WinForms.Guna2Button btninSignUp;
        private Guna.UI2.WinForms.Guna2TextBox txtinPassword;
        private System.Windows.Forms.Button btnPassShow;
        private System.Windows.Forms.Button btnPassHide;
        private System.Windows.Forms.Label lblHaveAcc;
        private System.Windows.Forms.LinkLabel fgPassword;
        public Guna.UI2.WinForms.Guna2TextBox txtinUserName;
        private System.Windows.Forms.Label lblAdmin;
        private Guna.UI.WinForms.GunaLinkLabel lnlblAdmin;
        private Guna.UI.WinForms.GunaLinkLabel lnlblEmp;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button btninSigninAdm;
        private System.Windows.Forms.LinkLabel lnlblFrAd;
        private System.Windows.Forms.Button btnCross;
    }
}

