﻿
namespace newdesign
{
    partial class WelcomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WelcomeForm));
            this.panelLeft = new System.Windows.Forms.Panel();
            this.btnMenuAd = new System.Windows.Forms.Button();
            this.btnAdAbout = new System.Windows.Forms.Button();
            this.btnMenuEmp = new System.Windows.Forms.Button();
            this.btnEdtMenu = new System.Windows.Forms.Button();
            this.btnSignOut = new System.Windows.Forms.Button();
            this.panelMove = new System.Windows.Forms.Panel();
            this.btnAbout = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.lblFood = new System.Windows.Forms.Label();
            this.panelTop = new System.Windows.Forms.Panel();
            this.btnCross = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panelLeft.SuspendLayout();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelLeft
            // 
            this.panelLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.panelLeft.Controls.Add(this.btnMenuAd);
            this.panelLeft.Controls.Add(this.btnAdAbout);
            this.panelLeft.Controls.Add(this.btnMenuEmp);
            this.panelLeft.Controls.Add(this.btnEdtMenu);
            this.panelLeft.Controls.Add(this.btnSignOut);
            this.panelLeft.Controls.Add(this.panelMove);
            this.panelLeft.Controls.Add(this.btnAbout);
            this.panelLeft.Controls.Add(this.btnMenu);
            this.panelLeft.Controls.Add(this.btnHome);
            this.panelLeft.Controls.Add(this.lblFood);
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Location = new System.Drawing.Point(0, 0);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(210, 746);
            this.panelLeft.TabIndex = 0;
            // 
            // btnMenuAd
            // 
            this.btnMenuAd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuAd.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuAd.Location = new System.Drawing.Point(31, 237);
            this.btnMenuAd.Name = "btnMenuAd";
            this.btnMenuAd.Size = new System.Drawing.Size(173, 70);
            this.btnMenuAd.TabIndex = 9;
            this.btnMenuAd.Text = "Menu";
            this.btnMenuAd.UseVisualStyleBackColor = true;
            this.btnMenuAd.Click += new System.EventHandler(this.btnMenuAd_Click);
            // 
            // btnAdAbout
            // 
            this.btnAdAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdAbout.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdAbout.Location = new System.Drawing.Point(31, 389);
            this.btnAdAbout.Name = "btnAdAbout";
            this.btnAdAbout.Size = new System.Drawing.Size(173, 70);
            this.btnAdAbout.TabIndex = 8;
            this.btnAdAbout.Text = "About Us";
            this.btnAdAbout.UseVisualStyleBackColor = true;
            this.btnAdAbout.Click += new System.EventHandler(this.btnAdAbout_Click);
            // 
            // btnMenuEmp
            // 
            this.btnMenuEmp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuEmp.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuEmp.Location = new System.Drawing.Point(31, 237);
            this.btnMenuEmp.Name = "btnMenuEmp";
            this.btnMenuEmp.Size = new System.Drawing.Size(173, 70);
            this.btnMenuEmp.TabIndex = 7;
            this.btnMenuEmp.Text = "Menu";
            this.btnMenuEmp.UseVisualStyleBackColor = true;
            this.btnMenuEmp.Click += new System.EventHandler(this.btnMenuEmp_Click);
            // 
            // btnEdtMenu
            // 
            this.btnEdtMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdtMenu.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdtMenu.Location = new System.Drawing.Point(31, 313);
            this.btnEdtMenu.Name = "btnEdtMenu";
            this.btnEdtMenu.Size = new System.Drawing.Size(173, 70);
            this.btnEdtMenu.TabIndex = 6;
            this.btnEdtMenu.Text = "Edit Menu";
            this.btnEdtMenu.UseVisualStyleBackColor = true;
            this.btnEdtMenu.Visible = false;
            this.btnEdtMenu.Click += new System.EventHandler(this.btnEdtMenu_Click);
            // 
            // btnSignOut
            // 
            this.btnSignOut.BackColor = System.Drawing.Color.OrangeRed;
            this.btnSignOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSignOut.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignOut.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSignOut.Location = new System.Drawing.Point(44, 667);
            this.btnSignOut.Name = "btnSignOut";
            this.btnSignOut.Size = new System.Drawing.Size(106, 47);
            this.btnSignOut.TabIndex = 5;
            this.btnSignOut.Text = "Sign Out";
            this.btnSignOut.UseVisualStyleBackColor = false;
            this.btnSignOut.Click += new System.EventHandler(this.btnSignOut_Click);
            // 
            // panelMove
            // 
            this.panelMove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panelMove.Location = new System.Drawing.Point(16, 161);
            this.panelMove.Name = "panelMove";
            this.panelMove.Size = new System.Drawing.Size(9, 70);
            this.panelMove.TabIndex = 0;
            // 
            // btnAbout
            // 
            this.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAbout.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbout.Location = new System.Drawing.Point(31, 389);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(173, 70);
            this.btnAbout.TabIndex = 4;
            this.btnAbout.Text = "About Us";
            this.btnAbout.UseVisualStyleBackColor = true;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenu.Location = new System.Drawing.Point(31, 237);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(173, 70);
            this.btnMenu.TabIndex = 3;
            this.btnMenu.Text = "Menu";
            this.btnMenu.UseVisualStyleBackColor = true;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnHome
            // 
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.Location = new System.Drawing.Point(31, 161);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(173, 70);
            this.btnHome.TabIndex = 2;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            this.btnHome.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            // 
            // lblFood
            // 
            this.lblFood.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFood.Location = new System.Drawing.Point(40, 9);
            this.lblFood.Name = "lblFood";
            this.lblFood.Size = new System.Drawing.Size(164, 64);
            this.lblFood.TabIndex = 0;
            this.lblFood.Text = "Food App";
            this.lblFood.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panelTop.Controls.Add(this.btnCross);
            this.panelTop.Controls.Add(this.label3);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(210, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1070, 77);
            this.panelTop.TabIndex = 1;
            // 
            // btnCross
            // 
            this.btnCross.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCross.Location = new System.Drawing.Point(1017, 9);
            this.btnCross.Name = "btnCross";
            this.btnCross.Size = new System.Drawing.Size(41, 38);
            this.btnCross.TabIndex = 2;
            this.btnCross.Text = "✖";
            this.btnCross.UseVisualStyleBackColor = true;
            this.btnCross.Click += new System.EventHandler(this.btnCross_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(365, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(184, 34);
            this.label3.TabIndex = 1;
            this.label3.Text = "BurGer Shop";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(230, 418);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(971, 328);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(210, 101);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1020, 311);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // WelcomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1280, 746);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.panelLeft);
            this.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "WelcomeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Welcome Form";
            this.panelLeft.ResumeLayout(false);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.Panel panelMove;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Label lblFood;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Button btnCross;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnSignOut;
        public System.Windows.Forms.Button btnEdtMenu;
        public System.Windows.Forms.Button btnAbout;
        public System.Windows.Forms.Button btnMenuEmp;
        public System.Windows.Forms.Button btnMenu;
        public System.Windows.Forms.Button btnAdAbout;
        public System.Windows.Forms.Button btnMenuAd;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}